## Instructions
main folder is as Assignment-231110030 and whole codebase is inside this folder.
The code base consists of 4 folders and one one microsoft Word Document:

1k extracted sentence : This folder contains randomly selected 1000 sentences for each language( English , Hindi, Marathi).



# Answer 1 and 2:
1.chatgpt:This folder contains 2 folder and one jupyter notebook inside it.

                data :- This folder contains .txt files of sentences which we have to translate.
                Translation :- This folder contains .txt file having translated sentences for all cases as mentiond in question.
                chatgpt.ipynb:- contains all the code required for chatgpt model translation ans score translation.

2.IndicTrans:This folder contains 4 folder and one Jupyter notebook  inside it.
                data:- this folder contains .txt files of sentences which of the model mentioned in question.
                indic_nlp_library:- contains required module and dependencies for loading model.
                Translation :-  This folder contains .txt file having translated sentences for all cases as mentiond in question.
                indicTrans_Model.ipynb:- contains all the code required for indicTrans  model translation ans score translation.

3.NLLB:-    
                data :- This folder contains .txt files of sentences which we have to translate.
                Translation :- This folder contains .txt file having translated sentences for all cases as mentiond in question.
                NLLB.ipynb:- contains all the code required for NLLB model translation ans score translation.


# Answer 3:
Answer 3.docx:- Microsoft word document cotains answer for question 3.

## How To RUN

The following steps can be used to run the code

1. unzip 231110030-assignment3 
2. Go to the respective folders and open jupyter notebook of respective folder.
3.Notebook is documented properly do not run code of translation because it will take long time.You can run code cells of score calculation.
4.Error may come because of missing library.
5. if show error because of library then please install library using "pip install library_name". 





