Root directory contains one jupyter notebook having all the coding questions solved,  
2 txt files containing manually annotated tags, tags given by chatgpt.
Report named Moin-231110030.pdf contains all results and observations.

How to run:
Open Moin-231110030.ipynb on google colab. Dataset would imported directly in the notebook online.
Since the size of the saved models is very big, i have not put them in the submission zip file.
